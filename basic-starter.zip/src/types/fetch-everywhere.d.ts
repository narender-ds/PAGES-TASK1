declare module "fetch-everywhere";

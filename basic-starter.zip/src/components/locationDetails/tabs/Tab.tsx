import React from "react";

const Tab = props => {
  return <div>{props.children}</div>;
};

export default Tab;

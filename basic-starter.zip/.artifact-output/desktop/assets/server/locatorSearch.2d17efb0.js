import{l as o,a as t,g as e}from"../static/locatorSearch-251f4ab7.js";import"../static/server.browser-befcc2f3.js";export{o as default,t as getHeadConfig,e as getPath};
